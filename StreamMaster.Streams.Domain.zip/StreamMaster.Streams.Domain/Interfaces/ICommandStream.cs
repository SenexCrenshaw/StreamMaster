﻿namespace StreamMaster.Streams.Domain.Interfaces;
public interface ICommandStream : ISMStream;
