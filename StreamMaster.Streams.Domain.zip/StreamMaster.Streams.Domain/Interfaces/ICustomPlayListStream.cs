﻿namespace StreamMaster.Streams.Domain.Interfaces;

public interface ICustomPlayListStream : ISMStream;