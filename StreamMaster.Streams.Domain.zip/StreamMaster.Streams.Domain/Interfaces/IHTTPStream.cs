﻿namespace StreamMaster.Streams.Domain.Interfaces;

public interface IHTTPStream : ISMStream;