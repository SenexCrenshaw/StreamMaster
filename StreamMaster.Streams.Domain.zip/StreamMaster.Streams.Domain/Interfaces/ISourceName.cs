﻿namespace StreamMaster.Streams.Domain.Interfaces;

public interface ISourceName
{
    string SourceName { get; }
}
