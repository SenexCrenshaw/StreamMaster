import React from 'react';
import { Checkbox } from 'primereact/checkbox';
import { getLine } from './getLine'; // Import the getLine function
import { UpdateChanges, getRecord } from '../SettingsUtils';
import { GetMessage } from '@lib/common/common';
import { getHelp } from '@lib/locales/help_en';
import { SettingDto, UpdateSettingRequest } from '@lib/smAPI/smapiTypes';

type CheckBoxLineProps = {
  field: string;
  currentSettingRequest: SettingDto;
  onChange: (existing: SettingDto, updatedValues: UpdateSettingRequest) => void | undefined;
};

export function getCheckBoxLine({ field, currentSettingRequest, onChange }: CheckBoxLineProps): React.ReactElement {
  const label = GetMessage(field);
  const help = getHelp(field);

  return getLine({
    label: `${label}:`,
    value: (
      <Checkbox
        className="bordered-text w-full text-left"
        onChange={(e) => UpdateChanges({ currentSettingRequest, field, onChange, value: !e.target.value })}
        checked={currentSettingRequest ? getRecord<SettingDto, boolean>(field, currentSettingRequest as SettingDto)! : false}
      />
    ),
    help
  });
}
